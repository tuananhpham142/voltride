export { default as SafeScreen } from './SafeScreen/SafeScreen';
